package google.hashcode.service;

public interface LibraryService {
    void manageLibrariesToScan(char dataSet);
}
