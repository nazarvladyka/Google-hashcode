package google.hashcode;

import google.hashcode.service.LibraryService;
import google.hashcode.service.impl.LibraryServiceImpl;

public class Main {
  public static void main(String[] args) {
    LibraryService libraryService = new LibraryServiceImpl();
//    System.out.println(Math.ceil(4.0000001));

//    libraryService.manageLibrariesToScan('A');
//    libraryService.manageLibrariesToScan('B');
//    libraryService.manageLibrariesToScan('C');
    libraryService.manageLibrariesToScan('D');
//    libraryService.manageLibrariesToScan('E');
//    libraryService.manageLibrariesToScan('F');
  }
}
